
//OMDb API key : 92ca64f5
const express = require('express')

const MovieCtrl = require('../controllers/movie-ctrl')


const router = express.Router()

// router.post('/movie', MovieCtrl.createMovie)
router.post('/setratting', MovieCtrl.setRatting)//this
// router.put('/movie/:id', MovieCtrl.updateMovie)
// router.delete('/movie/:id', MovieCtrl.deleteMovie)
// router.get('/movie/:id', MovieCtrl.getMovieById)
// router.get('/movies', MovieCtrl.getMovies)

module.exports = router