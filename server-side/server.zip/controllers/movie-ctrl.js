const Movie = require('../models/movie-model')
const User = require("../models/user-models");
// createMovie = (req, res) => {
//     const body = req.body

//     if (!body) {
//         return res.status(400).json({
//             success: false,
//             error: 'You must provide a movie',
//         })
//     }

//     const movie = new Movie(body)

//     if (!movie) {
//         return res.status(400).json({ success: false, error: err })
//     }

//     movie
//         .save()
//         .then(() => {
//             return res.status(400).json({
//                 success: true,
//                 id: movie._id,
//                 message: 'Movie created!',
//             })
//         })
//         .catch(error => {
//             return res.status(400).json({
//                 error,
//                 message: 'Movie not created!',
//             })
//         })
// }

setRatting = (req,res) => {
    const body = req.body
    // body = {title,imdbid,ratting,userid,imdbvotes,imdbratting}
    console.log(body);
    if(!body){
        return res.status(400).json({
            success: false,
            error: 'You must provide movie data+ratting!!',
        })
    }
    Movie.findOne({imdbid:body.imdbid}, (err,movie)=>{
        if(!movie)// it means movie is not in database so add it to database.
        {
            console.log(body);
            const mov = new Movie();
            mov.title = body.title;
            mov.imdbid = body.imdbid;
            mov.ratecount=body.imdbvotes+1;
            mov.totalratesum=parseInt(body.imdbratting*body.imdbvotes,10)+parseInt(body.ratting);
            mov.avgratting = mov.totalratesum/mov.ratecount;
            mov.save().then(()=>{
                User.findOne({_id :body.userid},(err1,user)=>{
                    if(err1){
                        return res.status(404).json({
                            error,
                            message: 'Movie updated but user not found!!',
                        })
                    }
                    user.userratting.push({"movieid":mov._id,"ratting":body.ratting,"imdbid":body.imdbid})
                    user.save().then(()=>{
                        return res.status(200).json({
                            success: true,
                            avgratting:mov.avgratting,
                            message: 'Movie successfully ratted!!',
                        })
                    })
                    .catch(error => {
                        return res.status(404).json({
                            error,
                            message: 'Movie created in database but userratting could not be updated!!',
                        })
                    })

                })
                
            })
            .catch(error => {
                return res.status(404).json({
                    error,
                    message: 'Movie could not be created somthing went wrong!!', 
                })
            })
        }
        else {
            movie.ratecount = movie.ratecount + 1;
            movie.totalratesum+=parseInt(body.ratting);
            movie.avgratting = movie.totalratesum/movie.ratecount;
            movie.save().then(()=>{
                User.findOne({_id :body.userid},(err1,user)=>{
                    if(err1){
                        return res.status(404).json({
                            error,
                            message: 'Movie updated but user not found!!',
                        })
                    }
                    user.userratting.push({"movieid":movie._id,"ratting":body.ratting,"imdbid":body.imdbid})
                    user.save().then(()=>{
                        return res.status(200).json({
                            success: true,
                            avgratting:movie.avgratting,
                            message: 'Movie successfully ratted!!',
                        })
                    })
                    .catch(error => {
                        return res.status(404).json({
                            error,
                            message: 'Movie updated in database but userratting could not be updated!!',
                        })
                    })

                })
                
                
            })
            .catch(error => {
                return res.status(404).json({
                    error,
                    message: 'Movie could not be updated somthing went wrong!!', 
                    })
                })
            }
        }
    )
}

// updateMovie = async (req, res) => {
//     const body = req.body

//     if (!body) {
//         return res.status(400).json({
//             success: false,
//             error: 'You must provide a body to update',
//         })
//     }

//     Movie.findOne({ _id: req.params.id }, (err, movie) => {
//         if (err) {
//             return res.status(404).json({
//                 err,
//                 message: 'Movie not found!',
//             })
//         }
//         movie.name = body.name
//         movie.time = body.time
//         movie.rating = body.rating
//         movie
//             .save()
//             .then(() => {
//                 return res.status(200).json({
//                     success: true,
//                     id: movie._id,
//                     message: 'Movie updated!',
//                 })
//             })
//             .catch(error => {
//                 return res.status(404).json({
//                     error,
//                     message: 'Movie not updated!',
//                 })
//             })
//     })
// }

// deleteMovie = async (req, res) => {
//     await Movie.findOneAndDelete({ _id: req.params.id }, (err, movie) => {
//         if (err) {
//             return res.status(400).json({ success: false, error: err })
//         }

//         if (!movie) {
//             return res
//                 .status(404)
//                 .json({ success: false, error: `Movie not found` })
//         }

//         return res.status(200).json({ success: true, data: movie })
//     }).catch(err => console.log(err))
// }

// getMovieById = async (req, res) => {
//     await Movie.findOne({ _id: req.params.id }, (err, movie) => {
//         if (err) {
//             return res.status(400).json({ success: false, error: err })
//         }

//         if (!movie) {
//             return res
//                 .status(404)
//                 .json({ success: false, error: `Movie not found` })
//         }
//         return res.status(200).json({ success: true, data: movie })
//     }).catch(err => console.log(err))
// }

// getMovies = async (req, res) => {
//     await Movie.find({}, (err, movies) => {
//         if (err) {
//             return res.status(400).json({ success: false, error: err })
//         }
//         if (!movies.length) {
//             return res
//                 .status(404)
//                 .json({ success: false, error: `Movie not found` })
//         }
//         return res.status(200).json({ success: true, data: movies })
//     }).catch(err => console.log(err))
// }

module.exports = {
    setRatting
}